--- the models must be copied in the JMT working folder created at installation. Typically in Windows a folder C:\Users\<user name >\JMT is generated with a subfolder JMT\example  that  contains the models. With Mac OS the folder is /Users/<user name>/JMT

--- the models are identified with the number of the Section of the book in which they are used. When possible, their names also summarize the Objective (Obj) and some other parameters.

--- for clarity, the tools used are also reported at the end of their names 

--- even small differencies are possible between the results incorporated in the models and those obtained with other computers due to the different code of the various versions of JMT executed

--- for conciseness, only the most important versions of the models in each case study are reported 
